const express = require("express");
const path = require('path');
const app = express()
const { MongoClient} = require('mongodb');
const url = "mongodb+srv://admin:password1234@mycluster.26bzk.mongodb.net/onlinedb?retryWrites=true&w=majority"


app.use(express.static(__dirname+"main.html"));
app.use(express.json());


app.get("/", function(req, res){
    res.sendFile(path.join(__dirname,'main.html'));
    console.log('received')
})

app.post("/add", (req, res) => {
    let {
        uname: username,scores
    } = req.body;
    
    let totalScore = 0;
    for (let score in scores) {
        totalScore += Number.parseInt(scores[score]);
    }
    let user = new User({
        username: username,
        score: totalScore
    });

    user
        .save()
        .then(dbRes => {
            res.redirect('/add');
        })
        .catch(err => {
            console.log('Error: ', err);
        });
});
app.post("/add", function(req,res){
    
        var flag=0;
        console.log('hi')
      
             
              MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, async function(err, db) {
                  if (err) throw err;
                  // db.close();
                  var dbo = db.db("onlinedb");
                  await dbo.collection("ISC-QUIZ").insertOne(req.body, function(err, result) {
                    if (err) 
                    {console.log(err) ;
                     res.send('Not OK')
                    }
})
})
},)
app.get('/result', (req, res) => {
    User
        .find()
        .then(dbres => {
            res.render('index.pug', {
                results: dbres
            });
        })
        .catch(err => {
            console.log('Error: ', err);
        })
        .finally(() => {
            console.log('Promise Completed.');
        });
});

              

app.listen(3000,function(error){
    if(error){console.log("error",error)}
    else{console.log("server is now live")}
});