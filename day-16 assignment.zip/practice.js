const express = require('express');

const app = express();

// middlewares
app.use(express.static(__dirname + '/public'));

// Routes
app.get('/dashboard', (req, res) => {
    res.render('practice2.pug');
});

app.get('/practice', (req, res) => {
    res.render('practice.pug');
});

app.listen(5000, () => console.log('Server live on http://localhost:5000'));