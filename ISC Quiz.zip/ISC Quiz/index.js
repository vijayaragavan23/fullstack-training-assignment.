const express = require("express");
const path = require('path');
const app = express()
const { MongoClient} = require('mongodb');
const url = "mongodb+srv://admin:password1234@mycluster.26bzk.mongodb.net/onlinedb?retryWrites=true&w=majority"


app.use(express.static(__dirname+"main.html"));
app.use(express.json());


app.get("/", function(req, res){
    res.sendFile(path.join(__dirname,'main.html'));
    console.log('received')
})
app.post("/add", function(req,res){
    
        var flag=0;
        console.log('hi')
      
             
              MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, async function(err, db) {
                  if (err) throw err;
                  // db.close();
                  var dbo = db.db("onlinedb");
                  await dbo.collection("ISC-QUIZ").insertOne(req.body, function(err, result) {
                    if (err) 
                    {console.log(err) ;
                     res.send('Not OK')
                    }
})
})
},)

              

app.listen(3000,function(error){
    if(error){console.log("error",error)}
    else{console.log("server is now live")}
});